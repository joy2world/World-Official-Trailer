<!doctype html>
<html lang="en-US" prefix="og: https://ogp.me/ns#" class="no-js-disabled">
<head>
	<!-- Global site tag (gtag.js) - Google Analytics -->
<script async src="https://www.googletagmanager.com/gtag/js?id=UA-214933845-4"></script>
<script>
  window.dataLayer = window.dataLayer || [];
  function gtag(){dataLayer.push(arguments);}
  gtag('js', new Date());

  gtag('config', 'UA-214933845-4');
</script>
    <meta name="yandex-verification" content="438961ef9796f291" />
	<meta name="msvalidate.01" content="AF62D587A9B1587AA251E6C318983E29" />
	<script async src="https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3987547606977043"
     crossorigin="anonymous"></script>
	<meta charset="UTF-8"/>
	<meta name="viewport" content="width=device-width, initial-scale=1"/>
	<link rel="profile" href="https://gmpg.org/xfn/11"/>
	
<!-- Search Engine Optimization by Rank Math - https://s.rankmath.com/home -->
<title>Page Not Found - World Official Trailer</title>
<meta name="robots" content="follow, noindex"/>
<meta property="og:locale" content="en_US" />
<meta property="og:type" content="article" />
<meta property="og:title" content="Page Not Found - World Official Trailer" />
<meta property="og:site_name" content="World Official Trailer" />
<meta property="og:image" content="http://localhost/worldofficialtrailer/wp-content/uploads/2021/12/WorldOfficialTrailer.jpg" />
<meta property="og:image:width" content="500" />
<meta property="og:image:height" content="500" />
<meta property="og:image:type" content="image/jpeg" />
<meta name="twitter:card" content="summary_large_image" />
<meta name="twitter:title" content="Page Not Found - World Official Trailer" />
<meta name="twitter:image" content="http://localhost/worldofficialtrailer/wp-content/uploads/2021/12/WorldOfficialTrailer.jpg" />
<script type="application/ld+json" class="rank-math-schema">{"@context":"https://schema.org","@graph":[{"@type":"EntertainmentBusiness","@id":"http://localhost/worldofficialtrailer/#organization","name":"World Official Trailer","url":"https://worldofficialtrailer.netlify.app/","logo":{"@type":"ImageObject","@id":"http://localhost/worldofficialtrailer/#logo","url":"http://localhost/worldofficialtrailer/wp-content/uploads/2021/12/WorldOfficialTrailer.jpg","caption":"World Official Trailer","inLanguage":"en-US","width":"500","height":"500"},"openingHours":["Monday,Tuesday,Wednesday,Thursday,Friday,Saturday,Sunday 09:00-17:00"],"image":{"@id":"http://localhost/worldofficialtrailer/#logo"}},{"@type":"WebSite","@id":"http://localhost/worldofficialtrailer/#website","url":"http://localhost/worldofficialtrailer","name":"World Official Trailer","publisher":{"@id":"http://localhost/worldofficialtrailer/#organization"},"inLanguage":"en-US"},{"@type":"WebPage","@id":"#webpage","url":"","name":"Page Not Found - World Official Trailer","isPartOf":{"@id":"http://localhost/worldofficialtrailer/#website"},"inLanguage":"en-US"}]}</script>
<!-- /Rank Math WordPress SEO plugin -->

<link rel='dns-prefetch' href='//s.w.org' />
<link rel="alternate" type="application/rss+xml" title="World Official Trailer &raquo; Feed" href="http://localhost/worldofficialtrailer/feed/" />
<link rel="alternate" type="application/rss+xml" title="World Official Trailer &raquo; Comments Feed" href="http://localhost/worldofficialtrailer/comments/feed/" />
		<script>
			window._wpemojiSettings = {"baseUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/72x72\/","ext":".png","svgUrl":"https:\/\/s.w.org\/images\/core\/emoji\/13.1.0\/svg\/","svgExt":".svg","source":{"concatemoji":"http:\/\/localhost\/worldofficialtrailer\/wp-includes\/js\/wp-emoji-release.min.js?ver=5.8.3"}};
			!function(e,a,t){var n,r,o,i=a.createElement("canvas"),p=i.getContext&&i.getContext("2d");function s(e,t){var a=String.fromCharCode;p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,e),0,0);e=i.toDataURL();return p.clearRect(0,0,i.width,i.height),p.fillText(a.apply(this,t),0,0),e===i.toDataURL()}function c(e){var t=a.createElement("script");t.src=e,t.defer=t.type="text/javascript",a.getElementsByTagName("head")[0].appendChild(t)}for(o=Array("flag","emoji"),t.supports={everything:!0,everythingExceptFlag:!0},r=0;r<o.length;r++)t.supports[o[r]]=function(e){if(!p||!p.fillText)return!1;switch(p.textBaseline="top",p.font="600 32px Arial",e){case"flag":return s([127987,65039,8205,9895,65039],[127987,65039,8203,9895,65039])?!1:!s([55356,56826,55356,56819],[55356,56826,8203,55356,56819])&&!s([55356,57332,56128,56423,56128,56418,56128,56421,56128,56430,56128,56423,56128,56447],[55356,57332,8203,56128,56423,8203,56128,56418,8203,56128,56421,8203,56128,56430,8203,56128,56423,8203,56128,56447]);case"emoji":return!s([10084,65039,8205,55357,56613],[10084,65039,8203,55357,56613])}return!1}(o[r]),t.supports.everything=t.supports.everything&&t.supports[o[r]],"flag"!==o[r]&&(t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&t.supports[o[r]]);t.supports.everythingExceptFlag=t.supports.everythingExceptFlag&&!t.supports.flag,t.DOMReady=!1,t.readyCallback=function(){t.DOMReady=!0},t.supports.everything||(n=function(){t.readyCallback()},a.addEventListener?(a.addEventListener("DOMContentLoaded",n,!1),e.addEventListener("load",n,!1)):(e.attachEvent("onload",n),a.attachEvent("onreadystatechange",function(){"complete"===a.readyState&&t.readyCallback()})),(n=t.source||{}).concatemoji?c(n.concatemoji):n.wpemoji&&n.twemoji&&(c(n.twemoji),c(n.wpemoji)))}(window,document,window._wpemojiSettings);
		</script>
		<style>
img.wp-smiley,
img.emoji {
	display: inline !important;
	border: none !important;
	box-shadow: none !important;
	height: 1em !important;
	width: 1em !important;
	margin: 0 .07em !important;
	vertical-align: -0.1em !important;
	background: none !important;
	padding: 0 !important;
}
</style>
	<link rel='stylesheet' id='wp-block-library-css'  href='http://localhost/worldofficialtrailer/wp-includes/css/dist/block-library/style.min.css?ver=5.8.3' media='all' />
<link rel='stylesheet' id='exs-style-css'  href='http://localhost/worldofficialtrailer/wp-content/themes/exs/assets/css/min/main-1200.css?ver=1.8.6' media='all' />
<link rel='stylesheet' id='exs-menu-desktop-type-style-css'  href='http://localhost/worldofficialtrailer/wp-content/themes/exs/assets/css/min/menu-desktop2.css?ver=1.8.6' media='all and (min-width: 1200px)' />
<link rel='stylesheet' id='all-in-one-video-gallery-backward-compatibility-css'  href='http://localhost/worldofficialtrailer/wp-content/plugins/all-in-one-video-gallery/public/assets/css/backward-compatibility.css?ver=2.5.0' media='all' />
<link rel='stylesheet' id='all-in-one-video-gallery-public-css'  href='http://localhost/worldofficialtrailer/wp-content/plugins/all-in-one-video-gallery/public/assets/css/public.css?ver=2.5.0' media='all' />
<style id='exs-style-inline-inline-css'>
:root{--colorLight:#ffffff;--colorLightRGB:255,255,255;--colorFont:#555555;--colorFontMuted:#666666;--colorBackground:#f7f7f7;--colorBorder:#e1e1e1;--colorDark:#ffffff;--colorDarkMuted:#222222;--colorMain:#a17de8;--colorMain2:#8a8dff;--colorMain3:#e678f5;--colorMain4:#7892f5;--btn-fs:.92em;--socialGap:1em;--wli-my:.5em;--sb-gap:2.5rem;--sideNavWidth:290px;--sideNavPX:20px;--mobileNavWidth:290px;--mobileNavPX:20px;}
</style>
<link rel="https://api.w.org/" href="http://localhost/worldofficialtrailer/wp-json/" /><link rel="EditURI" type="application/rsd+xml" title="RSD" href="http://localhost/worldofficialtrailer/xmlrpc.php?rsd" />
<link rel="wlwmanifest" type="application/wlwmanifest+xml" href="http://localhost/worldofficialtrailer/wp-includes/wlwmanifest.xml" /> 
<meta name="generator" content="WordPress 5.8.3" />
		<script>
			document.documentElement.className = document.documentElement.className.replace( 'no-js', 'js' );
		</script>
				<style>
			.no-js img.lazyload { display: none; }
			figure.wp-block-image img.lazyloading { min-width: 150px; }
							.lazyload, .lazyloading { opacity: 0; }
				.lazyloaded {
					opacity: 1;
					transition: opacity 400ms;
					transition-delay: 0ms;
				}
					</style>
		      <meta name="onesignal" content="wordpress-plugin"/>
            <script>

      window.OneSignal = window.OneSignal || [];

      OneSignal.push( function() {
        OneSignal.SERVICE_WORKER_UPDATER_PATH = 'OneSignalSDKUpdaterWorker.js';
                      OneSignal.SERVICE_WORKER_PATH = 'OneSignalSDKWorker.js';
                      OneSignal.SERVICE_WORKER_PARAM = { scope: '/worldofficialtrailer/wp-content/plugins/onesignal-free-web-push-notifications/sdk_files/push/onesignal/' };
        OneSignal.setDefaultNotificationUrl("http://localhost/worldofficialtrailer");
        var oneSignal_options = {};
        window._oneSignalInitOptions = oneSignal_options;

        oneSignal_options['wordpress'] = true;
oneSignal_options['appId'] = 'b0ef9f5c-b781-4b46-883d-e3acac4882eb';
oneSignal_options['allowLocalhostAsSecureOrigin'] = true;
oneSignal_options['welcomeNotification'] = { };
oneSignal_options['welcomeNotification']['title'] = "";
oneSignal_options['welcomeNotification']['message'] = "";
oneSignal_options['path'] = "http://localhost/worldofficialtrailer/wp-content/plugins/onesignal-free-web-push-notifications/sdk_files/";
oneSignal_options['persistNotification'] = true;
oneSignal_options['promptOptions'] = { };
                OneSignal.init(window._oneSignalInitOptions);
                OneSignal.showSlidedownPrompt();      });

      function documentInitOneSignal() {
        var oneSignal_elements = document.getElementsByClassName("OneSignal-prompt");

        var oneSignalLinkClickHandler = function(event) { OneSignal.push(['registerForPushNotifications']); event.preventDefault(); };        for(var i = 0; i < oneSignal_elements.length; i++)
          oneSignal_elements[i].addEventListener('click', oneSignalLinkClickHandler, false);
      }

      if (document.readyState === 'complete') {
           documentInitOneSignal();
      }
      else {
           window.addEventListener("load", function(event){
               documentInitOneSignal();
          });
      }
    </script>
<script id="google_gtagjs" src="https://www.googletagmanager.com/gtag/js?id=UA-214933845-4" async></script>
<script id="google_gtagjs-inline">
window.dataLayer = window.dataLayer || [];function gtag(){dataLayer.push(arguments);}gtag('js', new Date());gtag('config', 'UA-214933845-4', {} );
</script>
<link rel="icon" href="http://localhost/worldofficialtrailer/wp-content/uploads/2021/12/WorldOfficialTrailer.jpg" sizes="32x32" />
<link rel="icon" href="http://localhost/worldofficialtrailer/wp-content/uploads/2021/12/WorldOfficialTrailer.jpg" sizes="192x192" />
<link rel="apple-touch-icon" href="http://localhost/worldofficialtrailer/wp-content/uploads/2021/12/WorldOfficialTrailer.jpg" />
<meta name="msapplication-TileImage" content="http://localhost/worldofficialtrailer/wp-content/uploads/2021/12/WorldOfficialTrailer.jpg" />
</head>
<body id="body" class="error404 hfeed with-sidebar header-sticky" itemtype="https://schema.org/Blog" itemscope="itemscope" data-nonce="ebc48a5692" data-ajax="http://localhost/worldofficialtrailer/wp-admin/admin-ajax.php"
	>
<a id="skip_link" class="screen-reader-text skip-link" href="#main">Skip to content</a>
<div id="box" class="box-normal">
	<div id="top-wrap" class="container-1140"><div id="toplogo" class="toplogo  l  ">
	<div class="container container-md-flex">
		<a class="logo logo-left no-image  " href="http://localhost/worldofficialtrailer/" rel="home" itemprop="url">
			<span class="logo-text">
						<span class="logo-text-primary ">
				<span class="fs-26 fs-xl-26">
				World Official Trailer				</span>
			</span><!-- .logo-text-primary -->
									<span class="logo-text-secondary ">
				<span class="fs-26 fs-xl-26">
				Watch Official Trailer 24x7 Enjoy Trailers				</span>
			</span><!-- .logo-text-secondary -->
					</span><!-- .logo-text -->
	</a><!-- .logo -->
		<div class="search-social-wrap d-flex">
				<div class="header-search ">
			<button id="search_toggle"
					aria-controls="search_dropdown"
					aria-expanded="false"
					aria-label="Search Dropdown Toggler"
								>
				<span class="svg-icon icon-magnify"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24" viewBox="0 0 24 24">
	<path
		d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z"/>
</svg>
</span>			</button>
		</div><!-- .header-search -->
					<div class="social-links-wrap hidden">
				<span class="social-links"><a href="https://www.facebook.com/World-Group-Inc-110516234808802" class="social-icon social-icon-facebook"><span class="svg-icon icon-facebook"><svg style="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24" viewBox="0 0 24 24">
	<path d="M17,2V2H17V6H15C14.31,6 14,6.81 14,7.5V10H14L17,10V14H14V22H10V14H7V10H10V6A4,4 0 0,1 14,2H17Z"/>
</svg>
</span><span class="screen-reader-text">facebook</span></a><a href="https://twitter.com/wsh_highlights" class="social-icon social-icon-twitter"><span class="svg-icon icon-twitter"><svg style="" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24" viewBox="0 0 24 24">
	<path
		d="M22.46,6C21.69,6.35 20.86,6.58 20,6.69C20.88,6.16 21.56,5.32 21.88,4.31C21.05,4.81 20.13,5.16 19.16,5.36C18.37,4.5 17.26,4 16,4C13.65,4 11.73,5.92 11.73,8.29C11.73,8.63 11.77,8.96 11.84,9.27C8.28,9.09 5.11,7.38 3,4.79C2.63,5.42 2.42,6.16 2.42,6.94C2.42,8.43 3.17,9.75 4.33,10.5C3.62,10.5 2.96,10.3 2.38,10C2.38,10 2.38,10 2.38,10.03C2.38,12.11 3.86,13.85 5.82,14.24C5.46,14.34 5.08,14.39 4.69,14.39C4.42,14.39 4.15,14.36 3.89,14.31C4.43,16 6,17.26 7.89,17.29C6.43,18.45 4.58,19.13 2.56,19.13C2.22,19.13 1.88,19.11 1.54,19.07C3.44,20.29 5.7,21 8.12,21C16,21 20.33,14.46 20.33,8.79C20.33,8.6 20.33,8.42 20.32,8.23C21.16,7.63 21.88,6.87 22.46,6Z"/>
</svg>
</span><span class="screen-reader-text">twitter</span></a></span><!--.social-links-->			</div><!-- .social-links-wrap -->
		</div><!-- .search-social-wrap -->
	</div><!-- .container -->
</div><!-- #toplogo -->
<div id="header-affix-wrap" class="header-wrap l  ">
		<header
		id="header"
		data-bg="l"
		class="header header-3 no-logo l menu-center  always-sticky  ">
				<div class="container">
			<a class="logo logo-left no-image  " href="http://localhost/worldofficialtrailer/" rel="home" itemprop="url">
			<span class="logo-text">
						<span class="logo-text-primary ">
				<span class="fs-26 fs-xl-26">
				World Official Trailer				</span>
			</span><!-- .logo-text-primary -->
									<span class="logo-text-secondary ">
				<span class="fs-26 fs-xl-26">
				Watch Official Trailer 24x7 Enjoy Trailers				</span>
			</span><!-- .logo-text-secondary -->
					</span><!-- .logo-text -->
	</a><!-- .logo -->
			<div id="logo-align"></div>
			<div id="overlay"></div>
							<nav id="nav_top" class="top-nav" aria-label="Top Menu">
					<ul id="menu-wot" class="top-menu menu-low-items"><li id="menu-item-41" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-has-children menu-item-41"><a href="#" data-hover="World Other Websites"><span class="nav-menu-item-inside" data-hover="World Other Websites">World Other Websites</span></a>
<ul class="sub-menu">
	<li id="menu-item-42" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-42"><a target="_blank" rel="noopener" href="https://worldsportshighlight.netlify.app/" data-hover="World Sports Highlights"><span class="nav-menu-item-inside" data-hover="World Sports Highlights">World Sports Highlights</span></a></li>
	<li id="menu-item-43" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-43"><a target="_blank" rel="noopener" href="https://worldmoviesonline.netlify.app/" data-hover="World Movies Online"><span class="nav-menu-item-inside" data-hover="World Movies Online">World Movies Online</span></a></li>
	<li id="menu-item-44" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-44"><a target="_blank" rel="noopener" href="https://worldgamesdownload.netlify.app/" data-hover="World Games Download"><span class="nav-menu-item-inside" data-hover="World Games Download">World Games Download</span></a></li>
</ul>
</li>
<li id="menu-item-93" class="menu-item menu-item-type-custom menu-item-object-custom menu-item-home menu-item-93"><a href="http://localhost/worldofficialtrailer/" data-hover="Home"><span class="nav-menu-item-inside" data-hover="Home">Home</span></a></li>
<li id="menu-item-37" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-37"><a href="http://localhost/worldofficialtrailer/about-us/" data-hover="About Us"><span class="nav-menu-item-inside" data-hover="About Us">About Us</span></a></li>
<li id="menu-item-36" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-36"><a href="http://localhost/worldofficialtrailer/privacy-policy-2/" data-hover="Privacy Policy"><span class="nav-menu-item-inside" data-hover="Privacy Policy">Privacy Policy</span></a></li>
<li id="menu-item-35" class="menu-item menu-item-type-post_type menu-item-object-page menu-item-35"><a href="http://localhost/worldofficialtrailer/terms-conditions/" data-hover="Terms-Conditions"><span class="nav-menu-item-inside" data-hover="Terms-Conditions">Terms-Conditions</span></a></li>
</ul>						<button id="nav_close" class="nav-btn active"
								aria-controls="nav_top"
								aria-expanded="true"
								aria-label="Top Menu Close"
														>
							<span></span>
						</button>
									</nav><!-- .top-nav -->
								<button id="nav_toggle" class="nav-btn"
						aria-controls="nav_top"
						aria-expanded="false"
						aria-label="Top Menu Toggler"
										>
					<span></span>
				</button>
					</div><!-- .container -->
			</header><!-- #header -->
	</div><!--#header-affix-wrap-->
<section id="title" class="title title-1    container-1140"
	>
		<div class="container pt-3 pb-1">
					<h1 itemprop="headline">404</h1>
				</div><!-- .container -->
	</section><!-- #title -->
</div><!--#top-wrap-->	<div id="main" class="main section-404 container-720">
		<div class="container pt-5 pb-5">
			<main>
				<div id="layout" class="text-center">
					<div class="wrap-404">
												<h2 class="not_found mb-0 animate an__fadeInDown">
							<span class="has-huge-font-size">404</span>
						</h2>
																			<h5 class=" animate an__fadeInDown">
								Oops, page not found!							</h5>
																			<p class="animate an__fadeInLeft">
								You can search what interested:							</p>
																			<div class="widget widget_search mb-1 animate an__fadeInLeft">
								<form autocomplete="off" role="search" method="get" class="search-form" action="http://localhost/worldofficialtrailer/">

	<input
		type="search"
		id="search-form-61e117e005d3d"
		class="search-field"
		placeholder="Search"
		value=""
		name="s"
	/>
			<button type="submit" class="search-submit"><span class="svg-icon icon-magnify"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24" viewBox="0 0 24 24">
	<path
		d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z"/>
</svg>
</span>			<span class="screen-reader-text">Search</span>
		</button>
		
	<label for="search-form-61e117e005d3d" class="screen-reader-text">
		Search for:	</label>

</form><!-- .search-form -->
							</div>
																			<p class="mb-1 animate an__fadeInUp">
								Or							</p>
												<p class="mb-0 animate an__fadeInUp">
							<a href="http://localhost/worldofficialtrailer/" class="btn wp-block-button__link">
								Go To Home							</a>
						</p>
					</div>

				</div><!-- #layout -->
			</main>
		</div><!-- .container -->
	</div><!-- #main -->
<div id="bottom-wrap" class="container-1140"><footer id="footer"
		class="footer footer-1  fs-14 "
	>
		<div class="container pt-5 pb-3">
				<div class="layout-cols-1 layout-gap-30">
			<aside class="footer-widgets grid-wrapper">
				<div id="block-5" class="grid-item widget widget_block">

<p><script>(function(s,u,z,p){s.src=u,s.setAttribute('data-zone',z),p.appendChild(s);})(document.createElement('script'),'https://iclickcdn.com/tag.min.js',4719418,document.body||document.documentElement)</script></p>

</div>			</aside><!-- .footer-widgets> -->
		</div>
			</div><!-- .container -->
	</footer><!-- #footer -->
<div id="copyright" class="copyright  fs-20 "
	>
	<div class="container pt-1 pb-1">
		<div class="copyright-text text-center">
			World Official Trailer © <span class="copyright-year">2022</span> - All rights reserved		</div>
	</div><!-- .container -->
</div><!-- #copyright -->
</div><!-- #bottom-wrap --></div><!-- #box -->

<div id="search_dropdown">
	<form autocomplete="off" role="search" method="get" class="search-form" action="http://localhost/worldofficialtrailer/">

	<input
		type="search"
		id="search-form-61e117e006c1b"
		class="search-field"
		placeholder="Search"
		value=""
		name="s"
	/>
			<button type="submit" class="search-submit"><span class="svg-icon icon-magnify"><svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" version="1.1" width="24" height="24" viewBox="0 0 24 24">
	<path
		d="M9.5,3A6.5,6.5 0 0,1 16,9.5C16,11.11 15.41,12.59 14.44,13.73L14.71,14H15.5L20.5,19L19,20.5L14,15.5V14.71L13.73,14.44C12.59,15.41 11.11,16 9.5,16A6.5,6.5 0 0,1 3,9.5A6.5,6.5 0 0,1 9.5,3M9.5,5C7,5 5,7 5,9.5C5,12 7,14 9.5,14C12,14 14,12 14,9.5C14,7 12,5 9.5,5Z"/>
</svg>
</span>			<span class="screen-reader-text">Search</span>
		</button>
		
	<label for="search-form-61e117e006c1b" class="screen-reader-text">
		Search for:	</label>

</form><!-- .search-form -->
</div><!-- #search_dropdown -->
<button
	id="search_modal_close"
	class="nav-btn active"
	aria-controls="search_dropdown"
	aria-expanded="true"
	aria-label="Search Toggler"
	>
	<span></span>
</button>

	<a id="to-top" href="#body">
		<span class="screen-reader-text">
			Go to top		</span>
	</a>
<script src='http://localhost/worldofficialtrailer/wp-content/themes/exs/assets/js/min/init.js?ver=1.8.6' id='exs-init-script-js'></script>
<script src='http://localhost/worldofficialtrailer/wp-content/plugins/wp-smushit/app/assets/js/smush-lazy-load.min.js?ver=3.9.4' id='smush-lazy-load-js'></script>
<script src='http://localhost/worldofficialtrailer/wp-includes/js/wp-embed.min.js?ver=5.8.3' id='wp-embed-js'></script>
<script src='https://cdn.onesignal.com/sdks/OneSignalSDK.js?ver=5.8.3' async='async' id='remote_sdk-js'></script>
</body>
</html>
